@echo off
REM ============================================
REM EDUGEST DESKTOP 1.0
REM Script de Construction Automatisée
REM ============================================
REM Ce script crée automatiquement:
REM - Installation des dépendances
REM - Configuration de la BD
REM - Compilation du code
REM - Installeur .exe pour distribution
REM ============================================

setlocal enabledelayedexpansion
color 0A
title EduGest Desktop - Build Installer

echo.
echo ============================================
echo.
echo  ███████╗██████╗ ██╗   ██╗ ██████╗ ███████╗███████╗████████╗
echo  ██╔════╝██╔══██╗██║   ██║██╔════╝ ██╔════╝██╔════╝╚══██╔══╝
echo  █████╗  ██║  ██║██║   ██║██║  ███╗█████╗  ███████╗   ██║   
echo  ██╔══╝  ██║  ██║██║   ██║██║   ██║██╔══╝  ╚════██║   ██║   
echo  ███████╗██████╔╝╚██████╔╝╚██████╔╝███████╗███████║   ██║   
echo  ╚══════╝╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚══════╝   ╚═╝   
echo.
echo  Desktop 1.0 - Build Installer
echo  Création Automatique du Setup .exe
echo.
echo ============================================
echo.

REM Check if running as Administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] ERREUR: Veuillez exécuter en tant qu'Administrateur!
    echo.
    echo Clic droit sur ce fichier ^> Exécuter en tant qu'administrateur
    pause
    exit /b 1
)

echo [✓] Exécution en tant qu'Administrateur
echo.

REM ============================================
REM ÉTAPE 1: Vérifier Node.js
REM ============================================
echo [1/7] Vérification de Node.js...
node --version >nul 2>&1
if errorlevel 1 (
    echo [!] ERREUR: Node.js n'est pas installé!
    echo.
    echo Téléchargez Node.js LTS depuis: https://nodejs.org
    echo Puis relancez ce script.
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do set NODE_VERSION=%%i
echo [✓] Node.js %NODE_VERSION% trouvé

REM ============================================
REM ÉTAPE 2: Vérifier npm
REM ============================================
echo [2/7] Vérification de npm...
npm --version >nul 2>&1
if errorlevel 1 (
    echo [!] ERREUR: npm n'est pas installé!
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('npm --version') do set NPM_VERSION=%%i
echo [✓] npm %NPM_VERSION% trouvé

REM ============================================
REM ÉTAPE 3: Installer les dépendances
REM ============================================
echo.
echo [3/7] Installation des dépendances npm...
echo (Ceci peut prendre 2-3 minutes...)
echo.

call npm install --legacy-peer-deps
if errorlevel 1 (
    echo [!] ERREUR: Problème lors de l'installation
    echo.
    echo Vérifiez votre connexion Internet et réessayez
    pause
    exit /b 1
)
echo [✓] Dépendances installées

REM ============================================
REM ÉTAPE 4: Initialiser la base de données
REM ============================================
echo.
echo [4/7] Initialisation de la base de données...
call npm run db:migrate
if errorlevel 1 (
    echo [!] ERREUR: Problème lors de l'initialisation BD
    pause
    exit /b 1
)
echo [✓] Base de données initialisée

REM ============================================
REM ÉTAPE 5: Compiler TypeScript
REM ============================================
echo.
echo [5/7] Compilation du code TypeScript...
call npm run build
if errorlevel 1 (
    echo [!] ERREUR: Problème lors de la compilation
    pause
    exit /b 1
)
echo [✓] Compilation réussie

REM ============================================
REM ÉTAPE 6: Exécuter les tests
REM ============================================
echo.
echo [6/7] Exécution des tests...
call npm run test -- --passWithNoTests
if errorlevel 1 (
    echo [!] AVERTISSEMENT: Certains tests ont échoué
    echo Continuant quand même...
)
echo [✓] Tests terminés

REM ============================================
REM ÉTAPE 7: Créer l'installeur
REM ============================================
echo.
echo [7/7] Création de l'installeur Windows...
echo (Ceci peut prendre 5-8 minutes)
echo.

call npm run dist
if errorlevel 1 (
    echo [!] ERREUR: Problème lors de la création de l'installeur
    echo.
    echo Assurez-vous que vous avez Windows 10 ou plus récent
    pause
    exit /b 1
)

REM ============================================
REM SUCCÈS!
REM ============================================
echo.
echo ============================================
echo [✓] ✓ SUCCÈS! L'installeur a été créé!
echo ============================================
echo.
echo Votre fichier installeur se trouve ici:
echo.
echo   dist\EduGest-Setup-1.0.0.exe
echo.
echo PROCHAINES ÉTAPES:
echo.
echo 1. Double-cliquez sur le .exe pour installer
echo 2. L'application s'installera sur votre PC
echo 3. Vous pouvez partager le .exe avec d'autres
echo.
echo INFORMATIONS:
echo   - Installeur: %cd%\dist\EduGest-Setup-1.0.0.exe
echo   - Pour partager: Copiez le fichier .exe
echo   - Pour déployer: Envoyez le .exe aux écoles
echo.
echo ============================================
echo.
echo Appuyez sur une touche pour fermer...
pause
exit /b 0
