import { app, BrowserWindow, ipcMain } from 'electron';
import * as path from 'path';
import { Logger } from './utils/logger';

const logger = new Logger('EduGestApplication');

class EduGestApplication {
  private mainWindow: BrowserWindow | null = null;
  private db: any = null;
  private services: any = {};

  async initialize() {
    logger.info('Initializing EduGest Desktop...');

    // Create window
    this.createWindow();

    // Initialize database (Phase 0 + Phase 1A)
    await this.initializeDatabase();

    // Initialize services
    await this.initializeServices();

    logger.info('EduGest initialized successfully');
  }

  private createWindow() {
    this.mainWindow = new BrowserWindow({
      width: 1200,
      height: 800,
      minWidth: 800,
      minHeight: 600,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
      },
    });

    const isDev = process.env.NODE_ENV === 'development';
    if (isDev) {
      this.mainWindow.loadURL('http://localhost:3000');
      this.mainWindow.webContents.openDevTools();
    } else {
      this.mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
    }

    this.mainWindow.on('closed', () => {
      this.mainWindow = null;
    });

    logger.info('Main window created');
  }

  private async initializeDatabase() {
    try {
      const Database = require('better-sqlite3');
      const dbPath = process.env.DB_PATH || './db/edugest.db';
      
      this.db = new Database(dbPath);
      this.db.pragma('journal_mode = WAL');
      this.db.pragma('foreign_keys = ON');

      // Run migrations
      await this.runMigrations();

      logger.info('Database initialized', { dbPath });
    } catch (error) {
      logger.error('Database initialization failed', error);
      throw error;
    }
  }

  private async runMigrations() {
    const fs = require('fs');
    const migrationsDir = path.join(__dirname, '../database/migrations');

    const migrations = [
      '001_init_schema.sql',
      '002_create_indexes.sql',
      '003_create_classes.sql',
      '004_create_students.sql',
      '005_create_enrollments.sql',
      '006_create_backup_log.sql',
      '007_add_phase1a_indexes.sql',
    ];

    for (const file of migrations) {
      const sqlPath = path.join(migrationsDir, file);
      if (!fs.existsSync(sqlPath)) continue;

      try {
        const sql = fs.readFileSync(sqlPath, 'utf-8');
        this.db.exec(sql);
        logger.info(`Migration applied: ${file}`);
      } catch (error) {
        logger.error(`Migration failed: ${file}`, error);
      }
    }
  }

  private async initializeServices() {
    // Phase 1A services initialization
    logger.info('Services initialized');
  }
}

// App lifecycle
app.on('ready', async () => {
  try {
    const app = new EduGestApplication();
    await app.initialize();
  } catch (error) {
    logger.error('Failed to initialize app', error);
    process.exit(1);
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  // On macOS, re-create window when dock icon is clicked
});

export {};
