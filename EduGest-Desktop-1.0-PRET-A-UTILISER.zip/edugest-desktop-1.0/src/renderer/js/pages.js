// Global app state
let APP = {
  currentPage: 'dashboard',
  currentSchoolId: null,
  currentUser: null,
};

// Initialize app
async function initApp() {
  try {
    // Hide splash
    document.getElementById('splash-screen').classList.add('hidden');

    // Check if logged in
    const session = await window.app?.auth?.validateSession?.();
    if (session && session.valid) {
      APP.currentUser = session.user;
      APP.currentSchoolId = session.user.schoolId;
      showMainApp();
      loadDashboard();
    } else {
      showLoginPage();
    }
  } catch (error) {
    console.error('Init error:', error);
    showLoginPage();
  }
}

// Show login page
function showLoginPage() {
  document.getElementById('login-page').classList.remove('hidden');
  document.getElementById('main-app').classList.add('hidden');
}

// Show main app
function showMainApp() {
  document.getElementById('login-page').classList.add('hidden');
  document.getElementById('main-app').classList.remove('hidden');
}

// Handle login
async function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  try {
    const result = await window.app?.auth?.login?.(email, password);
    if (result && result.valid) {
      APP.currentUser = result.user;
      APP.currentSchoolId = result.user.schoolId;
      showMainApp();
      loadDashboard();
    } else {
      showError('Email ou mot de passe incorrect');
    }
  } catch (error) {
    showError(error.message || 'Erreur de connexion');
  }
}

// Show error
function showError(message) {
  const errorDiv = document.getElementById('login-error');
  errorDiv.textContent = message;
  errorDiv.classList.add('error-message');
}

// Logout
async function logout() {
  try {
    await window.app?.auth?.logout?.();
    showLoginPage();
  } catch (error) {
    console.error('Logout error:', error);
  }
}

// Navigate to page
function goToPage(pageName) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));

  // Show selected page
  const page = document.getElementById(`${pageName}-page`);
  if (page) {
    page.classList.remove('hidden');
  }

  // Update sidebar active link
  document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
  event.target.classList.add('active');

  APP.currentPage = pageName;

  // Load page data
  if (pageName === 'dashboard') {
    loadDashboard();
  } else if (pageName === 'students') {
    loadStudents();
  } else if (pageName === 'backup') {
    loadBackups();
  } else if (pageName === 'reports') {
    loadReports();
  }
}

// Load Dashboard
async function loadDashboard() {
  try {
    const result = await window.app?.reports?.dashboardStats?.(APP.currentSchoolId);
    if (result && result.data) {
      const stats = result.data;
      document.getElementById('total-students').textContent = stats.totalStudents || 0;
      document.getElementById('active-students').textContent = stats.activeStudents || 0;
      document.getElementById('total-classes').textContent = stats.totalClasses || 0;
      document.getElementById('last-backup').textContent = stats.lastBackup
        ? new Date(stats.lastBackup).toLocaleDateString('fr-FR')
        : 'Jamais';

      // Load enrollment report
      loadEnrollmentReport();
    }
  } catch (error) {
    console.error('Dashboard load error:', error);
  }
}

// Load Enrollment Report
async function loadEnrollmentReport() {
  try {
    const result = await window.app?.reports?.enrollment?.(APP.currentSchoolId);
    if (result && result.data) {
      const tbody = document.getElementById('enrollment-tbody');
      tbody.innerHTML = result.data.map(row => `
        <tr>
          <td>${row.className || ''}</td>
          <td>${row.level || ''}</td>
          <td>${row.totalEnrolled || 0}</td>
          <td>${row.activeCount || 0}</td>
        </tr>
      `).join('');
    }
  } catch (error) {
    console.error('Report load error:', error);
  }
}

// Load Students
async function loadStudents() {
  try {
    const result = await window.app?.students?.list?.(APP.currentSchoolId, {
      limit: 50,
      offset: 0,
    });
    if (result && result.data) {
      const tbody = document.getElementById('students-tbody');
      tbody.innerHTML = result.data.students.map(s => `
        <tr>
          <td>${s.first_name || ''}</td>
          <td>${s.last_name || ''}</td>
          <td>${s.email || ''}</td>
          <td>${s.enrollment_status || 'active'}</td>
          <td>
            <button class="btn" onclick="editStudent('${s.id}')">✏️</button>
            <button class="btn" onclick="deleteStudent('${s.id}')">🗑️</button>
          </td>
        </tr>
      `).join('');
    }
  } catch (error) {
    console.error('Students load error:', error);
  }
}

// Show Add Student Form
function showAddStudentForm() {
  document.getElementById('student-modal').classList.remove('hidden');
  document.getElementById('student-form').reset();
}

// Close modal
function closeModal(modalId) {
  document.getElementById(modalId).classList.add('hidden');
}

// Save Student
async function saveStudent(event) {
  event.preventDefault();

  const firstName = document.getElementById('student-firstName').value;
  const lastName = document.getElementById('student-lastName').value;
  const email = document.getElementById('student-email').value;

  try {
    const result = await window.app?.students?.create?.(APP.currentSchoolId, {
      firstName,
      lastName,
      email: email || undefined,
    });

    if (result && result.data) {
      closeModal('student-modal');
      loadStudents();
      showNotification('Élève enregistré', 'success');
    }
  } catch (error) {
    showNotification(error.message || 'Erreur', 'error');
  }
}

// Delete Student
async function deleteStudent(studentId) {
  if (!confirm('Êtes-vous sûr?')) return;

  try {
    const result = await window.app?.students?.delete?.(APP.currentSchoolId, studentId);
    if (result && result.data !== undefined) {
      loadStudents();
      showNotification('Élève supprimé', 'success');
    }
  } catch (error) {
    showNotification('Erreur lors de la suppression', 'error');
  }
}

// Search Students
async function searchStudents() {
  const search = document.getElementById('search-students').value;
  try {
    const result = await window.app?.students?.list?.(APP.currentSchoolId, {
      search,
      limit: 50,
      offset: 0,
    });
    if (result && result.data) {
      const tbody = document.getElementById('students-tbody');
      tbody.innerHTML = result.data.students.map(s => `
        <tr>
          <td>${s.first_name || ''}</td>
          <td>${s.last_name || ''}</td>
          <td>${s.email || ''}</td>
          <td>${s.enrollment_status || 'active'}</td>
          <td>
            <button class="btn" onclick="editStudent('${s.id}')">✏️</button>
            <button class="btn" onclick="deleteStudent('${s.id}')">🗑️</button>
          </td>
        </tr>
      `).join('');
    }
  } catch (error) {
    console.error('Search error:', error);
  }
}

// Load Backups
async function loadBackups() {
  try {
    const result = await window.app?.backup?.list?.(APP.currentSchoolId);
    if (result && result.data) {
      console.log('Backups:', result.data);
    }
  } catch (error) {
    console.error('Backups load error:', error);
  }
}

// Create Backup
async function createBackup() {
  try {
    const statusDiv = document.getElementById('backup-status');
    statusDiv.textContent = '⏳ Création en cours...';

    const result = await window.app?.backup?.create?.(APP.currentSchoolId);
    if (result && result.data) {
      statusDiv.textContent = '✅ Sauvegarde créée avec succès';
      loadBackups();
    }
  } catch (error) {
    document.getElementById('backup-status').textContent = '❌ Erreur lors de la sauvegarde';
  }
}

// Load Reports
async function loadReports() {
  try {
    const result = await window.app?.reports?.dashboardStats?.(APP.currentSchoolId);
    if (result && result.data) {
      console.log('Reports:', result.data);
    }
  } catch (error) {
    console.error('Reports load error:', error);
  }
}

// Export Students
async function exportStudents() {
  try {
    const result = await window.app?.export?.studentsCsv?.(APP.currentSchoolId);
    if (result && result.data) {
      showNotification('Export en cours...', 'success');
    }
  } catch (error) {
    showNotification('Erreur lors de l\'export', 'error');
  }
}

// Show Notification
function showNotification(message, type = 'info') {
  const div = document.createElement('div');
  div.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 4px;
    background: ${type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#d1ecf1'};
    color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#0c5460'};
    z-index: 2000;
    animation: slideIn 0.3s ease-out;
  `;
  div.textContent = message;
  document.body.appendChild(div);

  setTimeout(() => div.remove(), 3000);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initApp);
