// Class levels by school type
export const CLASS_LEVELS = {
  CEM: ['6', '5', '4', '3'],
  Lycée: ['2nde', '1ère', 'Terminale'],
} as const;

// Sections by class level
export const CLASS_SECTIONS = {
  '2nde': [],
  '1ère': ['L', 'S', 'G'],
  'Terminale': ['L', 'S', 'G'],
} as const;

// Enrollment statuses
export const ENROLLMENT_STATUSES = [
  'active',
  'suspended',
  'transferred',
  'graduated',
  'deleted',
] as const;

// User roles
export const USER_ROLES = [
  'admin',
  'principal',
  'proviseur',
  'gestionnaire',
  'consultation',
] as const;

// School types
export const SCHOOL_TYPES = ['CEM', 'Lycée'] as const;

// Academic years
export const CURRENT_ACADEMIC_YEAR = '2026-2027';

// Pagination
export const DEFAULT_PAGE_SIZE = 50;
export const MAX_PAGE_SIZE = 200;

// Backup settings
export const BACKUP_RETENTION_DAYS = 30;
export const AUTO_BACKUP_TIME = '23:00';

// Feature flags
export const FEATURES = {
  AUTO_BACKUP: true,
  BULK_IMPORT: true,
  CSV_EXPORT: true,
  STUDENT_EXPORT: true,
  ENROLLMENT_REPORTS: true,
} as const;
