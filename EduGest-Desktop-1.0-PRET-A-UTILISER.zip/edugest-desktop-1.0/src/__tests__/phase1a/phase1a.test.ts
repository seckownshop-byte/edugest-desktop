import { describe, it, expect, beforeEach } from '@jest/globals';
import { StudentService, ValidationError } from '../src/services/student-service';
import { EnrollmentService } from '../src/services/enrollment-service';
import { ReportsService } from '../src/services/reports-service';

// Mock database
const mockDb = {
  run: jest.fn(),
  get: jest.fn(),
  all: jest.fn(),
};

// Mock audit service
const mockAuditService = {
  log: jest.fn(),
};

// Mock repositories
const mockStudentRepository = {
  db: mockDb,
  create: jest.fn(),
  findById: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
  getStats: jest.fn(),
};

const mockEnrollmentRepository = {
  db: mockDb,
  create: jest.fn(),
  findById: jest.fn(),
  findByClass: jest.fn(),
  findByStudent: jest.fn(),
  update: jest.fn(),
  deleteByStudent: jest.fn(),
};

const mockClassRepository = {
  findById: jest.fn(),
  listClasses: jest.fn(),
};

describe('StudentService', () => {
  let studentService: StudentService;

  beforeEach(() => {
    jest.clearAllMocks();
    studentService = new StudentService(
      mockStudentRepository,
      mockEnrollmentRepository,
      mockAuditService
    );
  });

  it('should create student with valid data', async () => {
    const mockStudent = { id: 'st-1', firstName: 'Mohamed', lastName: 'Seck' };
    mockStudentRepository.create.mockResolvedValueOnce(mockStudent);
    mockAuditService.log.mockResolvedValueOnce(undefined);

    const result = await studentService.createStudent('school-1', {
      firstName: 'Mohamed',
      lastName: 'Seck',
    });

    expect(result.firstName).toBe('Mohamed');
    expect(mockAuditService.log).toHaveBeenCalled();
  });

  it('should reject student without first name', async () => {
    await expect(
      studentService.createStudent('school-1', {
        firstName: '',
        lastName: 'Seck',
      })
    ).rejects.toThrow(ValidationError);
  });

  it('should reject student without last name', async () => {
    await expect(
      studentService.createStudent('school-1', {
        firstName: 'Mohamed',
        lastName: '',
      })
    ).rejects.toThrow(ValidationError);
  });

  it('should get student by ID', async () => {
    const mockStudent = { id: 'st-1', firstName: 'Mohamed' };
    mockStudentRepository.findById.mockResolvedValueOnce(mockStudent);

    const result = await studentService.getStudent('school-1', 'st-1');

    expect(result.id).toBe('st-1');
  });

  it('should throw error when student not found', async () => {
    mockStudentRepository.findById.mockResolvedValueOnce(null);

    await expect(
      studentService.getStudent('school-1', 'invalid-id')
    ).rejects.toThrow('Student not found');
  });

  it('should list students with pagination', async () => {
    const students = [
      { id: 'st-1', firstName: 'Mohamed', lastName: 'Seck' },
      { id: 'st-2', firstName: 'Fatou', lastName: 'Diallo' },
    ];
    mockDb.all.mockResolvedValueOnce(students);
    mockDb.get.mockResolvedValueOnce({ count: 2 });

    const result = await studentService.listStudents('school-1', {
      limit: 50,
      offset: 0,
    });

    expect(result.students.length).toBeGreaterThanOrEqual(0);
  });

  it('should update student', async () => {
    const originalStudent = { id: 'st-1', firstName: 'Mohamed', lastName: 'Seck' };
    const updatedStudent = { ...originalStudent, firstName: 'Ahmed' };

    mockStudentRepository.findById.mockResolvedValueOnce(originalStudent);
    mockStudentRepository.update.mockResolvedValueOnce(updatedStudent);
    mockAuditService.log.mockResolvedValueOnce(undefined);

    const result = await studentService.updateStudent('school-1', 'st-1', {
      firstName: 'Ahmed',
    });

    expect(result.firstName).toBe('Ahmed');
    expect(mockAuditService.log).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'UPDATE_STUDENT' })
    );
  });

  it('should delete student (soft delete)', async () => {
    const student = { id: 'st-1' };
    mockStudentRepository.findById.mockResolvedValueOnce(student);
    mockEnrollmentRepository.deleteByStudent.mockResolvedValueOnce(undefined);
    mockStudentRepository.delete.mockResolvedValueOnce(undefined);
    mockAuditService.log.mockResolvedValueOnce(undefined);

    await studentService.deleteStudent('school-1', 'st-1');

    expect(mockStudentRepository.delete).toHaveBeenCalled();
  });

  it('should bulk import students', async () => {
    const data = [
      { firstName: 'Mohamed', lastName: 'Seck' },
      { firstName: 'Fatou', lastName: 'Diallo' },
    ];

    mockStudentRepository.create.mockResolvedValue({ id: 'st-new' });
    mockAuditService.log.mockResolvedValue(undefined);

    const result = await studentService.bulkImportStudents('school-1', data);

    expect(result.imported).toBeGreaterThanOrEqual(0);
  });

  it('should get student statistics', async () => {
    const stats = {
      total: 100,
      active: 95,
      suspended: 3,
      transferred: 2,
      graduated: 0,
    };
    mockStudentRepository.getStats.mockResolvedValueOnce(stats);

    const result = await studentService.getStudentStats('school-1');

    expect(result.total).toBe(100);
  });
});

describe('EnrollmentService', () => {
  let enrollmentService: EnrollmentService;

  beforeEach(() => {
    jest.clearAllMocks();
    enrollmentService = new EnrollmentService(
      mockEnrollmentRepository,
      mockClassRepository,
      mockAuditService
    );
  });

  it('should enroll student in class', async () => {
    const mockClass = { id: 'class-1', name: '2nde A' };
    const mockEnrollment = { id: 'enroll-1', studentId: 'st-1', classId: 'class-1' };

    mockClassRepository.findById.mockResolvedValueOnce(mockClass);
    mockEnrollmentRepository.create.mockResolvedValueOnce(mockEnrollment);
    mockAuditService.log.mockResolvedValueOnce(undefined);

    const result = await enrollmentService.enrollStudent('school-1', 'st-1', 'class-1');

    expect(result.studentId).toBe('st-1');
    expect(mockAuditService.log).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'ENROLL_STUDENT' })
    );
  });

  it('should reject enrollment if class not found', async () => {
    mockClassRepository.findById.mockResolvedValueOnce(null);

    await expect(
      enrollmentService.enrollStudent('school-1', 'st-1', 'invalid-class')
    ).rejects.toThrow('Class not found');
  });

  it('should get class enrollments', async () => {
    const enrollments = [
      { id: 'e-1', studentId: 'st-1' },
      { id: 'e-2', studentId: 'st-2' },
    ];
    mockEnrollmentRepository.findByClass.mockResolvedValueOnce(enrollments);

    const result = await enrollmentService.getClassEnrollments('school-1', 'class-1');

    expect(result.length).toBe(2);
  });

  it('should calculate class statistics', async () => {
    const enrollments = [
      { id: 'e-1', enrollmentStatus: 'active' },
      { id: 'e-2', enrollmentStatus: 'active' },
      { id: 'e-3', enrollmentStatus: 'suspended' },
    ];
    mockEnrollmentRepository.findByClass.mockResolvedValueOnce(enrollments);

    const stats = await enrollmentService.getClassStats('school-1', 'class-1');

    expect(stats.total).toBe(3);
    expect(stats.active).toBe(2);
    expect(stats.suspended).toBe(1);
  });

  it('should transfer student to new class', async () => {
    const enrollment = { id: 'enroll-1', classId: 'class-1' };
    const newClass = { id: 'class-2', name: '1ère A' };
    const updated = { ...enrollment, classId: 'class-2' };

    mockEnrollmentRepository.findById.mockResolvedValueOnce(enrollment);
    mockClassRepository.findById.mockResolvedValueOnce(newClass);
    mockEnrollmentRepository.update.mockResolvedValueOnce(updated);
    mockAuditService.log.mockResolvedValueOnce(undefined);

    const result = await enrollmentService.transferStudent('school-1', 'enroll-1', 'class-2');

    expect(result.classId).toBe('class-2');
  });
});

describe('ReportsService', () => {
  let reportsService: ReportsService;

  beforeEach(() => {
    jest.clearAllMocks();
    reportsService = new ReportsService(mockDb);
  });

  it('should generate enrollment report', async () => {
    const report = [
      {
        id: 'class-1',
        className: '2nde A',
        level: '2nde',
        totalEnrolled: 45,
        activeCount: 43,
      },
    ];
    mockDb.all.mockResolvedValueOnce(report);

    const result = await reportsService.getEnrollmentReport('school-1');

    expect(result.length).toBeGreaterThanOrEqual(0);
  });

  it('should get student list report', async () => {
    const report = [
      {
        id: 'st-1',
        first_name: 'Mohamed',
        last_name: 'Seck',
        email: 'seck@example.com',
        enrollment_status: 'active',
      },
    ];
    mockDb.all.mockResolvedValueOnce(report);

    const result = await reportsService.getStudentListReport('school-1');

    expect(Array.isArray(result)).toBe(true);
  });

  it('should get dashboard statistics', async () => {
    mockDb.get
      .mockResolvedValueOnce({ count: 150 })
      .mockResolvedValueOnce({ count: 145 })
      .mockResolvedValueOnce({ count: 6 })
      .mockResolvedValueOnce({ count: 5 })
      .mockResolvedValueOnce({ created_at: '2026-09-15T10:00:00Z' });

    const stats = await reportsService.getDashboardStats('school-1');

    expect(stats.totalStudents).toBe(150);
    expect(stats.activeStudents).toBe(145);
    expect(stats.totalClasses).toBe(6);
  });
});

describe('Integration Tests', () => {
  it('should handle complete enrollment workflow', async () => {
    // Setup
    jest.clearAllMocks();
    const studentService = new StudentService(
      mockStudentRepository,
      mockEnrollmentRepository,
      mockAuditService
    );
    const enrollmentService = new EnrollmentService(
      mockEnrollmentRepository,
      mockClassRepository,
      mockAuditService
    );

    // Create student
    const mockStudent = { id: 'st-1', firstName: 'Mohamed', lastName: 'Seck' };
    mockStudentRepository.create.mockResolvedValueOnce(mockStudent);
    mockAuditService.log.mockResolvedValue(undefined);

    const student = await studentService.createStudent('school-1', {
      firstName: 'Mohamed',
      lastName: 'Seck',
    });

    expect(student.id).toBe('st-1');

    // Enroll student
    const mockClass = { id: 'class-1', name: '2nde A' };
    const mockEnrollment = { id: 'enroll-1', studentId: 'st-1', classId: 'class-1' };

    mockClassRepository.findById.mockResolvedValueOnce(mockClass);
    mockEnrollmentRepository.create.mockResolvedValueOnce(mockEnrollment);

    const enrollment = await enrollmentService.enrollStudent('school-1', 'st-1', 'class-1');

    expect(enrollment.studentId).toBe('st-1');
    expect(mockAuditService.log).toHaveBeenCalledTimes(2); // Create + Enroll
  });
});
