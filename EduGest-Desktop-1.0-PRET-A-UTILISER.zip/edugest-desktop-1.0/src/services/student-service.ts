import { Logger } from '../utils/logger';

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export interface StudentCreateDTO {
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  gender?: 'M' | 'F';
  email?: string;
  phone?: string;
  parentName?: string;
  parentPhone?: string;
}

export interface StudentUpdateDTO {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  parentName?: string;
  parentPhone?: string;
  enrollmentStatus?: string;
}

export class StudentService {
  private logger = new Logger('StudentService');
  private studentRepository: any;
  private enrollmentRepository: any;
  private auditService: any;

  constructor(studentRepository: any, enrollmentRepository: any, auditService: any) {
    this.studentRepository = studentRepository;
    this.enrollmentRepository = enrollmentRepository;
    this.auditService = auditService;
  }

  async createStudent(schoolId: string, dto: StudentCreateDTO): Promise<any> {
    try {
      if (!dto.firstName || !dto.lastName) {
        throw new ValidationError('First name and last name required');
      }

      const student = await this.studentRepository.create(schoolId, {
        firstName: dto.firstName.trim(),
        lastName: dto.lastName.trim(),
        dateOfBirth: dto.dateOfBirth,
        gender: dto.gender,
        email: dto.email,
        phone: dto.phone,
        parentName: dto.parentName,
        parentPhone: dto.parentPhone,
        enrollmentStatus: 'active',
      });

      await this.auditService.log({
        action: 'CREATE_STUDENT',
        entityType: 'STUDENT',
        entityId: student.id,
        details: { firstName: student.firstName, lastName: student.lastName },
        schoolId,
      });

      this.logger.info('Student created', { studentId: student.id, schoolId });
      return student;
    } catch (error) {
      this.logger.error('Failed to create student', error);
      throw error;
    }
  }

  async getStudent(schoolId: string, studentId: string): Promise<any> {
    const student = await this.studentRepository.findById(schoolId, studentId);
    if (!student) {
      throw new ValidationError('Student not found');
    }
    return student;
  }

  async listStudents(
    schoolId: string,
    options?: {
      classId?: string;
      enrollmentStatus?: string;
      search?: string;
      limit?: number;
      offset?: number;
    }
  ): Promise<{ students: any[]; total: number }> {
    try {
      const limit = options?.limit || 50;
      const offset = options?.offset || 0;

      let query = `SELECT s.* FROM students s WHERE s.school_id = ?`;
      const params: any[] = [schoolId];

      if (options?.classId) {
        query += ` AND s.id IN (SELECT student_id FROM enrollments WHERE class_id = ? AND school_id = ?)`;
        params.push(options.classId, schoolId);
      }

      if (options?.enrollmentStatus) {
        query += ` AND s.enrollment_status = ?`;
        params.push(options.enrollmentStatus);
      }

      if (options?.search) {
        query += ` AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.email LIKE ?)`;
        const searchTerm = `%${options.search}%`;
        params.push(searchTerm, searchTerm, searchTerm);
      }

      const countResult = await this.studentRepository.db.get(
        query.replace('SELECT s.*', 'SELECT COUNT(*) as count'),
        params
      );
      const total = countResult?.count || 0;

      query += ` ORDER BY s.last_name, s.first_name LIMIT ? OFFSET ?`;
      params.push(limit, offset);

      const students = await this.studentRepository.db.all(query, params);
      return { students, total };
    } catch (error) {
      this.logger.error('Failed to list students', error);
      throw error;
    }
  }

  async updateStudent(schoolId: string, studentId: string, dto: StudentUpdateDTO): Promise<any> {
    try {
      const student = await this.getStudent(schoolId, studentId);

      const updated = await this.studentRepository.update(schoolId, studentId, {
        firstName: dto.firstName || student.firstName,
        lastName: dto.lastName || student.lastName,
        email: dto.email !== undefined ? dto.email : student.email,
        phone: dto.phone !== undefined ? dto.phone : student.phone,
        parentName: dto.parentName !== undefined ? dto.parentName : student.parentName,
        parentPhone: dto.parentPhone !== undefined ? dto.parentPhone : student.parentPhone,
        enrollmentStatus: dto.enrollmentStatus || student.enrollmentStatus,
      });

      await this.auditService.log({
        action: 'UPDATE_STUDENT',
        entityType: 'STUDENT',
        entityId: studentId,
        details: { changes: dto },
        schoolId,
      });

      return updated;
    } catch (error) {
      this.logger.error('Failed to update student', error);
      throw error;
    }
  }

  async deleteStudent(schoolId: string, studentId: string): Promise<void> {
    try {
      await this.enrollmentRepository.deleteByStudent(studentId);
      await this.studentRepository.delete(schoolId, studentId);

      await this.auditService.log({
        action: 'DELETE_STUDENT',
        entityType: 'STUDENT',
        entityId: studentId,
        details: {},
        schoolId,
      });

      this.logger.info('Student deleted', { studentId, schoolId });
    } catch (error) {
      this.logger.error('Failed to delete student', error);
      throw error;
    }
  }

  async bulkImportStudents(schoolId: string, data: StudentCreateDTO[]): Promise<{
    imported: number;
    errors: Array<{ index: number; error: string }>;
  }> {
    try {
      const results = { imported: 0, errors: [] as any[] };

      for (let i = 0; i < data.length; i++) {
        try {
          await this.createStudent(schoolId, data[i]);
          results.imported++;
        } catch (error) {
          results.errors.push({
            index: i,
            error: error instanceof Error ? error.message : 'Unknown error',
          });
        }
      }

      this.logger.info('Bulk import complete', {
        schoolId,
        imported: results.imported,
        errors: results.errors.length,
      });

      return results;
    } catch (error) {
      this.logger.error('Bulk import failed', error);
      throw error;
    }
  }

  async getStudentStats(schoolId: string): Promise<any> {
    try {
      const stats = await this.studentRepository.getStats(schoolId);
      return stats;
    } catch (error) {
      this.logger.error('Failed to get student stats', error);
      throw error;
    }
  }
}
