import { Logger } from '../utils/logger';

export class ReportsService {
  private logger = new Logger('ReportsService');
  private db: any;

  constructor(db: any) {
    this.db = db;
  }

  async getEnrollmentReport(schoolId: string): Promise<any[]> {
    try {
      const report = await this.db.all(
        `SELECT 
          c.id,
          c.name as className,
          c.level,
          c.section,
          COUNT(DISTINCT e.student_id) as totalEnrolled,
          SUM(CASE WHEN s.enrollment_status = 'active' THEN 1 ELSE 0 END) as activeCount
        FROM classes c
        LEFT JOIN enrollments e ON c.id = e.class_id
        LEFT JOIN students s ON e.student_id = s.id
        WHERE c.school_id = ?
        GROUP BY c.id, c.name, c.level, c.section
        ORDER BY c.level, c.name`,
        [schoolId]
      );

      return report;
    } catch (error) {
      this.logger.error('Failed to generate enrollment report', error);
      throw error;
    }
  }

  async getStudentListReport(schoolId: string, classId?: string): Promise<any[]> {
    try {
      let query = `
        SELECT 
          s.id,
          s.first_name,
          s.last_name,
          s.date_of_birth,
          s.email,
          s.enrollment_status,
          GROUP_CONCAT(c.name) as classes
        FROM students s
        LEFT JOIN enrollments e ON s.id = e.student_id
        LEFT JOIN classes c ON e.class_id = c.id
        WHERE s.school_id = ?
      `;

      const params: any[] = [schoolId];

      if (classId) {
        query += ` AND e.class_id = ?`;
        params.push(classId);
      }

      query += ` GROUP BY s.id ORDER BY s.last_name, s.first_name`;

      return await this.db.all(query, params);
    } catch (error) {
      this.logger.error('Failed to generate student list report', error);
      throw error;
    }
  }

  async getDashboardStats(schoolId: string): Promise<any> {
    try {
      const totalStudents = await this.db.get(
        'SELECT COUNT(*) as count FROM students WHERE school_id = ?',
        [schoolId]
      );

      const activeStudents = await this.db.get(
        "SELECT COUNT(*) as count FROM students WHERE school_id = ? AND enrollment_status = 'active'",
        [schoolId]
      );

      const totalClasses = await this.db.get(
        'SELECT COUNT(*) as count FROM classes WHERE school_id = ?',
        [schoolId]
      );

      const classesWithEnrollment = await this.db.get(
        `SELECT COUNT(DISTINCT class_id) as count FROM enrollments WHERE school_id = ?`,
        [schoolId]
      );

      const lastBackup = await this.db.get(
        'SELECT created_at FROM backup_log WHERE school_id = ? ORDER BY created_at DESC LIMIT 1',
        [schoolId]
      );

      return {
        totalStudents: totalStudents?.count || 0,
        activeStudents: activeStudents?.count || 0,
        totalClasses: totalClasses?.count || 0,
        classesWithEnrollment: classesWithEnrollment?.count || 0,
        lastBackup: lastBackup?.created_at || null,
      };
    } catch (error) {
      this.logger.error('Failed to get dashboard stats', error);
      throw error;
    }
  }
}
