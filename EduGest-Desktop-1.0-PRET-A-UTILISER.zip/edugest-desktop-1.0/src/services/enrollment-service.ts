import { Logger } from '../utils/logger';

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class EnrollmentService {
  private logger = new Logger('EnrollmentService');
  private enrollmentRepository: any;
  private classRepository: any;
  private auditService: any;

  constructor(enrollmentRepository: any, classRepository: any, auditService: any) {
    this.enrollmentRepository = enrollmentRepository;
    this.classRepository = classRepository;
    this.auditService = auditService;
  }

  async enrollStudent(
    schoolId: string,
    studentId: string,
    classId: string,
    academicYear: string = '2026-2027'
  ): Promise<any> {
    try {
      const classItem = await this.classRepository.findById(schoolId, classId);
      if (!classItem) {
        throw new ValidationError('Class not found');
      }

      const enrollment = await this.enrollmentRepository.create({
        schoolId,
        studentId,
        classId,
        academicYear,
        enrollmentStatus: 'active',
      });

      await this.auditService.log({
        action: 'ENROLL_STUDENT',
        entityType: 'ENROLLMENT',
        entityId: enrollment.id,
        details: { studentId, classId, academicYear },
        schoolId,
      });

      this.logger.info('Student enrolled', { studentId, classId, schoolId });
      return enrollment;
    } catch (error) {
      this.logger.error('Failed to enroll student', error);
      throw error;
    }
  }

  async getClassEnrollments(schoolId: string, classId: string): Promise<any[]> {
    try {
      return await this.enrollmentRepository.findByClass(schoolId, classId);
    } catch (error) {
      this.logger.error('Failed to get class enrollments', error);
      throw error;
    }
  }

  async getStudentEnrollments(schoolId: string, studentId: string): Promise<any[]> {
    try {
      return await this.enrollmentRepository.findByStudent(schoolId, studentId);
    } catch (error) {
      this.logger.error('Failed to get student enrollments', error);
      throw error;
    }
  }

  async transferStudent(
    schoolId: string,
    enrollmentId: string,
    newClassId: string
  ): Promise<any> {
    try {
      const enrollment = await this.enrollmentRepository.findById(enrollmentId);
      if (!enrollment) {
        throw new ValidationError('Enrollment not found');
      }

      const newClass = await this.classRepository.findById(schoolId, newClassId);
      if (!newClass) {
        throw new ValidationError('New class not found');
      }

      const updated = await this.enrollmentRepository.update(enrollmentId, {
        classId: newClassId,
      });

      await this.auditService.log({
        action: 'TRANSFER_STUDENT',
        entityType: 'ENROLLMENT',
        entityId: enrollmentId,
        details: { fromClass: enrollment.classId, toClass: newClassId },
        schoolId,
      });

      return updated;
    } catch (error) {
      this.logger.error('Failed to transfer student', error);
      throw error;
    }
  }

  async getClassStats(schoolId: string, classId: string): Promise<any> {
    try {
      const enrollments = await this.enrollmentRepository.findByClass(schoolId, classId);

      return {
        total: enrollments.length,
        active: enrollments.filter((e: any) => e.enrollmentStatus === 'active').length,
        suspended: enrollments.filter((e: any) => e.enrollmentStatus === 'suspended').length,
      };
    } catch (error) {
      this.logger.error('Failed to get class stats', error);
      throw error;
    }
  }
}
