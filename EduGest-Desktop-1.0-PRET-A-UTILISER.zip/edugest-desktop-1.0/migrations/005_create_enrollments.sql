CREATE TABLE IF NOT EXISTS enrollments (
  id TEXT PRIMARY KEY,
  school_id TEXT NOT NULL,
  student_id TEXT NOT NULL,
  class_id TEXT NOT NULL,
  academic_year TEXT NOT NULL,
  enrollment_status TEXT DEFAULT 'active',
  enrollment_date TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE,
  CHECK (enrollment_status IN ('active', 'suspended', 'transferred', 'graduated'))
);

CREATE INDEX IF NOT EXISTS idx_enrollments_school_class ON enrollments(school_id, class_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_student ON enrollments(student_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_class ON enrollments(class_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_status ON enrollments(enrollment_status);
CREATE INDEX IF NOT EXISTS idx_enrollments_academic_year ON enrollments(academic_year);
CREATE INDEX IF NOT EXISTS idx_enrollments_class_status ON enrollments(class_id, enrollment_status);

CREATE UNIQUE INDEX IF NOT EXISTS idx_enrollments_unique_per_class 
  ON enrollments(student_id, class_id, academic_year);
