-- Schema version tracking
INSERT OR IGNORE INTO schema_version (version, applied_at, description)
VALUES 
  ('003', datetime('now'), 'Create classes table'),
  ('004', datetime('now'), 'Create students table'),
  ('005', datetime('now'), 'Create enrollments table'),
  ('006', datetime('now'), 'Create backup_log table'),
  ('007', datetime('now'), 'Add Phase 1A indexes');
