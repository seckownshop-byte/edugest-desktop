CREATE TABLE IF NOT EXISTS backup_log (
  id TEXT PRIMARY KEY,
  school_id TEXT NOT NULL,
  backup_type TEXT NOT NULL,
  backup_size INTEGER,
  backup_file_path TEXT NOT NULL,
  checksum TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  CHECK (backup_type IN ('manual', 'automatic'))
);

CREATE INDEX IF NOT EXISTS idx_backup_log_school ON backup_log(school_id);
CREATE INDEX IF NOT EXISTS idx_backup_log_date ON backup_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_backup_log_type ON backup_log(backup_type);
CREATE INDEX IF NOT EXISTS idx_backup_log_school_date ON backup_log(school_id, created_at DESC);
